import { Layout } from '@/components/layout/Layout'
import { useApp } from '@/store/AppContext'

export default function Products() {
  const { state } = useApp()
  const ts = state.finishedProducts.reduce((s, p) => s + p.stock, 0)
  const tm = state.finishedProducts.reduce((s, p) => s + p.producedMonth, 0)
  const tv = state.finishedProducts.reduce((s, p) => s + p.stock * p.price, 0)

  return (
    <Layout title="Готовая продукция">
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-white border border-[#D4CFC8] p-4"><div className="text-[12px] text-[#5E5E5E] mb-1">Позиций</div><div className="text-[24px] font-bold">{state.finishedProducts.length}</div></div>
        <div className="bg-white border border-[#D4CFC8] p-4"><div className="text-[12px] text-[#5E5E5E] mb-1">Остаток (меш.)</div><div className="text-[24px] font-bold">{ts.toLocaleString()}</div></div>
        <div className="bg-white border border-[#D4CFC8] p-4"><div className="text-[12px] text-[#5E5E5E] mb-1">Выпущено за месяц</div><div className="text-[24px] font-bold">{tm.toLocaleString()}</div></div>
        <div className="bg-white border border-[#D4CFC8] p-4"><div className="text-[12px] text-[#5E5E5E] mb-1">Стоимость остатков</div><div className="text-[24px] font-bold">{tv.toLocaleString()} ₽</div></div>
      </div>

      <div className="bg-white border border-[#D4CFC8]">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="bg-[#EFEBE6]">
              <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">№</th>
              <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Продукт</th>
              <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Упаковка</th>
              <th className="px-4 py-3 text-[12px] font-semibold text-right border-b-2 border-[#2B2B2B]">Остаток</th>
              <th className="px-4 py-3 text-[12px] font-semibold text-right border-b-2 border-[#2B2B2B]">Сегодня</th>
              <th className="px-4 py-3 text-[12px] font-semibold text-right border-b-2 border-[#2B2B2B]">За месяц</th>
              <th className="px-4 py-3 text-[12px] font-semibold text-right border-b-2 border-[#2B2B2B]">Цена ₽</th>
              <th className="px-4 py-3 text-[12px] font-semibold text-right border-b-2 border-[#2B2B2B]">Сумма ₽</th>
            </tr></thead>
            <tbody className="divide-y divide-[#F6F5F2]">
              {state.finishedProducts.map((p, idx) => (
                <tr key={p.id} className={`h-12 ${idx % 2 === 1 ? 'bg-[#F6F5F2]' : 'bg-white'} hover:bg-[#EFEBE6]`}>
                  <td className="px-4 text-[12px] font-mono text-[#5E5E5E]">{p.id}</td>
                  <td className="px-4 text-[13px] font-medium">{p.name}</td>
                  <td className="px-4 text-[12px] text-[#5E5E5E]">{p.packaging}</td>
                  <td className="px-4 text-[13px] text-right font-mono">{p.stock.toLocaleString()}</td>
                  <td className="px-4 text-[13px] text-[#5A8A6E] text-right font-mono font-medium">+{p.producedToday.toLocaleString()}</td>
                  <td className="px-4 text-[12px] text-right font-mono">{p.producedMonth.toLocaleString()}</td>
                  <td className="px-4 text-[12px] text-right font-mono">{p.price.toLocaleString()}</td>
                  <td className="px-4 text-[12px] text-right font-mono">{(p.stock * p.price).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 border-t border-[#D4CFC8] flex items-center justify-between">
          <span className="text-[11px] text-[#9E9E9E]">Итого: {state.finishedProducts.length} позиций</span>
          <span className="text-[12px] font-medium">Общая стоимость: {tv.toLocaleString()} ₽</span>
        </div>
      </div>
    </Layout>
  )
}
