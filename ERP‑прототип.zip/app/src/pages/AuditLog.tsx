import { useState } from 'react'
import { Layout } from '@/components/layout/Layout'
import { useApp } from '@/store/AppContext'
import { Search } from 'lucide-react'

const actionColors: Record<string, string> = {
  'Создан приход сырья': 'bg-[#5A8A6E]/10 text-[#5A8A6E]',
  'Проведена передача в цех': 'bg-[#2A5C8D]/10 text-[#2A5C8D]',
  'Завершено производство': 'bg-[#5A8A6E]/10 text-[#5A8A6E]',
  'Запущено производство': 'bg-[#F0A830]/10 text-[#F0A830]',
  'Создана отгрузка': 'bg-[#2A5C8D]/10 text-[#2A5C8D]',
  'Отгружено клиенту': 'bg-[#5A8A6E]/10 text-[#5A8A6E]',
  'Создано списание': 'bg-[#C0563F]/10 text-[#C0563F]',
  'Изменён статус прихода': 'bg-[#F0A830]/10 text-[#F0A830]',
}

const docColors: Record<string, string> = {
  'Приход': 'bg-[#5A8A6E]/15 text-[#5A8A6E]',
  'Передача': 'bg-[#2A5C8D]/15 text-[#2A5C8D]',
  'Производство': 'bg-[#F0A830]/15 text-[#F0A830]',
  'Отгрузка': 'bg-[#C0563F]/15 text-[#C0563F]',
  'Списание': 'bg-[#9E9E9E]/15 text-[#9E9E9E]',
}

export default function AuditLog() {
  const { state } = useApp()
  const [search, setSearch] = useState('')
  const [docFilter, setDocFilter] = useState('all')

  const filtered = state.auditLog.filter((e) => {
    const ms = e.action.toLowerCase().includes(search.toLowerCase()) || e.object.toLowerCase().includes(search.toLowerCase()) || e.user.toLowerCase().includes(search.toLowerCase()) || e.documentId.toLowerCase().includes(search.toLowerCase())
    return ms && (docFilter === 'all' || e.documentType === docFilter)
  })

  return (
    <Layout title="Журнал операций">
      <div className="bg-white border border-[#D4CFC8] p-4 mb-4 flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9E9E9E]" />
          <input type="text" placeholder="Поиск по действию, объекту, пользователю..." value={search} onChange={(e) => setSearch(e.target.value)} className="h-9 w-full pl-9 pr-3 text-[12px] bg-[#F6F5F2] border border-[#D4CFC8] rounded focus:outline-none focus:border-[#C0563F]" />
        </div>
        <select value={docFilter} onChange={(e) => setDocFilter(e.target.value)} className="h-9 px-3 text-[12px] bg-[#F6F5F2] border border-[#D4CFC8] rounded">
          <option value="all">Все типы</option><option value="Приход">Приход</option><option value="Передача">Передача</option><option value="Производство">Производство</option><option value="Отгрузка">Отгрузка</option><option value="Списание">Списание</option>
        </select>
        <span className="text-[12px] text-[#5E5E5E] ml-auto">Записей: <strong>{filtered.length}</strong></span>
      </div>

      <div className="bg-white border border-[#D4CFC8]">
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="bg-[#EFEBE6]">
            <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Время</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Пользователь</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Действие</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Тип док.</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Документ</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Объект</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-center border-b-2 border-[#2B2B2B]">Изменение</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-center border-b-2 border-[#2B2B2B]">Статус</th>
          </tr></thead>
            <tbody className="divide-y divide-[#F6F5F2]">{filtered.map((e, idx) => (
              <tr key={e.id} className={`h-12 ${idx % 2 === 1 ? 'bg-[#F6F5F2]' : 'bg-white'} hover:bg-[#EFEBE6]`}>
                <td className="px-4 text-[11px] font-mono text-[#5E5E5E] whitespace-nowrap">{e.timestamp}</td>
                <td className="px-4 text-[12px] font-medium text-[#2B2B2B]">{e.user}</td>
                <td className="px-4"><span className={`inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium rounded ${actionColors[e.action] || 'bg-[#9E9E9E]/10 text-[#9E9E9E]'}`}>{e.action}</span></td>
                <td className="px-4"><span className={`inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium rounded ${docColors[e.documentType] || 'bg-[#9E9E9E]/10 text-[#9E9E9E]'}`}>{e.documentType}</span></td>
                <td className="px-4 text-[11px] font-mono text-[#5E5E5E]">{e.documentId}</td>
                <td className="px-4 text-[12px] text-[#2B2B2B]">{e.object}</td>
                <td className="px-4 text-center">{e.oldValue && e.newValue ? <span className="text-[10px] text-[#5E5E5E]">{e.oldValue} → <span className="text-[#C0563F]">{e.newValue}</span></span> : <span className="text-[10px] text-[#9E9E9E]">—</span>}</td>
                <td className="px-4 text-center"><span className={`inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium rounded ${e.status === 'Успешно' ? 'bg-[#5A8A6E]/10 text-[#5A8A6E]' : 'bg-[#F0A830]/10 text-[#F0A830]'}`}>{e.status}</span></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </div>
    </Layout>
  )
}
