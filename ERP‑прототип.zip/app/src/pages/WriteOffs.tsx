import { useState } from 'react'
import { Layout } from '@/components/layout/Layout'
import { useApp, writeOffTypeLabels } from '@/store/AppContext'
import type { WriteOff } from '@/store/AppContext'
import { Plus, X } from 'lucide-react'

const typeOptions: { key: WriteOff['type']; label: string }[] = [
  { key: 'losses', label: 'Технологические потери' },
  { key: 'defect', label: 'Брак' },
  { key: 'spoilage', label: 'Порча' },
  { key: 'inventory', label: 'Инвентаризационная корректировка' },
  { key: 'other', label: 'Прочее' },
]

export default function WriteOffs() {
  const { state, dispatch } = useApp()
  const [showForm, setShowForm] = useState(false)
  const [type, setType] = useState<WriteOff['type']>('losses')
  const [targetType, setTargetType] = useState<'material' | 'product'>('material')
  const [targetId, setTargetId] = useState('')
  const [quantity, setQuantity] = useState('')
  const [reason, setReason] = useState('')
  const [responsible, setResponsible] = useState('')

  const targets = targetType === 'material' ? state.rawMaterials : state.finishedProducts

  const hSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const t = targets.find((x) => x.id === targetId)
    if (!t) return
    dispatch({ type: 'ADD_WRITEOFF', payload: { date: '25.06.2024', type, targetType, targetId, targetName: t.name, quantity: Number(quantity), unit: t.unit, reason, responsible } })
    setShowForm(false); setType('losses'); setTargetId(''); setQuantity(''); setReason(''); setResponsible('')
  }

  return (
    <Layout title="Списания">
      <div className="bg-white border border-[#D4CFC8] p-4 mb-4 flex items-center justify-between">
        <span className="text-[13px] text-[#5E5E5E]">Всего: <strong>{state.writeOffs.length}</strong> | Проведено: <strong className="text-[#5A8A6E]">{state.writeOffs.filter((w) => w.status === 'posted').length}</strong></span>
        <button onClick={() => setShowForm(!showForm)} className="h-9 px-4 bg-[#C0563F] text-white text-[13px] font-medium rounded hover:bg-[#A84835] flex items-center gap-2"><Plus size={15} strokeWidth={2.5} /> Создать списание</button>
      </div>

      {showForm && (
        <form onSubmit={hSubmit} className="bg-white border border-[#D4CFC8] p-5 mb-4">
          <div className="flex items-center justify-between mb-4"><h3 className="text-[14px] font-semibold">Новое списание</h3><button type="button" onClick={() => setShowForm(false)} className="text-[#9E9E9E] hover:text-[#2B2B2B]"><X size={18} /></button></div>
          <div className="grid grid-cols-4 gap-4 mb-4">
            <div><label className="text-[12px] text-[#5E5E5E] block mb-1">Тип</label><select value={type} onChange={(e) => setType(e.target.value as WriteOff['type'])} className="h-9 w-full px-3 text-[13px] bg-[#F6F5F2] border border-[#D4CFC8] rounded">{typeOptions.map((o) => <option key={o.key} value={o.key}>{o.label}</option>)}</select></div>
            <div><label className="text-[12px] text-[#5E5E5E] block mb-1">Объект</label><select value={targetType} onChange={(e) => { setTargetType(e.target.value as 'material' | 'product'); setTargetId('') }} className="h-9 w-full px-3 text-[13px] bg-[#F6F5F2] border border-[#D4CFC8] rounded"><option value="material">Сырьё</option><option value="product">Готовая продукция</option></select></div>
            <div><label className="text-[12px] text-[#5E5E5E] block mb-1">Наименование</label><select value={targetId} onChange={(e) => setTargetId(e.target.value)} className="h-9 w-full px-3 text-[13px] bg-[#F6F5F2] border border-[#D4CFC8] rounded"><option value="">Выберите...</option>{targets.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></div>
            <div><label className="text-[12px] text-[#5E5E5E] block mb-1">Количество</label><input type="number" value={quantity} onChange={(e) => setQuantity(e.target.value)} className="h-9 w-full px-3 text-[13px] bg-[#F6F5F2] border border-[#D4CFC8] rounded" min="0" step="0.01" /></div>
          </div>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div><label className="text-[12px] text-[#5E5E5E] block mb-1">Причина</label><input type="text" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Укажите причину..." className="h-9 w-full px-3 text-[13px] bg-[#F6F5F2] border border-[#D4CFC8] rounded" /></div>
            <div><label className="text-[12px] text-[#5E5E5E] block mb-1">Ответственный</label><input type="text" value={responsible} onChange={(e) => setResponsible(e.target.value)} className="h-9 w-full px-3 text-[13px] bg-[#F6F5F2] border border-[#D4CFC8] rounded" /></div>
          </div>
          <div className="flex justify-end gap-3"><button type="button" onClick={() => setShowForm(false)} className="h-9 px-4 text-[13px] font-medium text-[#5E5E5E] bg-white border border-[#D4CFC8] rounded hover:bg-[#F6F5F2]">Отмена</button><button type="submit" disabled={!targetId || !quantity} className="h-9 px-5 text-[13px] font-medium text-white bg-[#C0563F] rounded hover:bg-[#A84835] disabled:opacity-50">Создать</button></div>
        </form>
      )}

      <div className="bg-white border border-[#D4CFC8]">
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="bg-[#EFEBE6]">
            <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">№</th><th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Дата</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Тип</th><th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Объект</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-right border-b-2 border-[#2B2B2B]">Кол-во</th><th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Причина</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Ответственный</th><th className="px-4 py-3 text-[12px] font-semibold text-center border-b-2 border-[#2B2B2B]">Статус</th><th className="px-4 py-3 text-[12px] font-semibold text-center border-b-2 border-[#2B2B2B]"></th>
          </tr></thead>
            <tbody className="divide-y divide-[#F6F5F2]">{state.writeOffs.slice().reverse().map((w, idx) => (
              <tr key={w.id} className={`h-12 ${idx % 2 === 1 ? 'bg-[#F6F5F2]' : 'bg-white'} hover:bg-[#EFEBE6]`}>
                <td className="px-4 text-[12px] font-mono text-[#5E5E5E]">{w.id}</td><td className="px-4 text-[12px]">{w.date}</td>
                <td className="px-4 text-[12px]"><span className={`inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium rounded ${w.type === 'losses' ? 'bg-[#F0A830]/10 text-[#F0A830]' : w.type === 'defect' ? 'bg-[#C0563F]/10 text-[#C0563F]' : w.type === 'spoilage' ? 'bg-[#C0563F]/10 text-[#C0563F]' : w.type === 'inventory' ? 'bg-[#2A5C8D]/10 text-[#2A5C8D]' : 'bg-[#9E9E9E]/10 text-[#9E9E9E]'}`}>{writeOffTypeLabels[w.type]}</span></td>
                <td className="px-4 text-[12px]">{w.targetName} <span className="text-[10px] text-[#9E9E9E]">({w.targetType === 'material' ? 'сырьё' : 'продукция'})</span></td>
                <td className="px-4 text-[12px] text-right font-mono">{w.quantity} {w.unit}</td>
                <td className="px-4 text-[12px] text-[#5E5E5E]">{w.reason}</td>
                <td className="px-4 text-[12px] text-[#5E5E5E]">{w.responsible}</td>
                <td className="px-4 text-center"><span className={`inline-flex items-center px-2 py-0.5 text-[11px] font-medium rounded ${w.status === 'posted' ? 'bg-[#5A8A6E]/15 text-[#5A8A6E]' : w.status === 'draft' ? 'bg-[#F0A830]/15 text-[#F0A830]' : 'bg-[#C0563F]/15 text-[#C0563F]'}`}>{w.status === 'posted' ? 'Проведен' : w.status === 'draft' ? 'Черновик' : 'Отменен'}</span></td>
                <td className="px-4 text-center">{w.status === 'draft' && <button onClick={() => dispatch({ type: 'UPDATE_WRITEOFF_STATUS', id: w.id, status: 'posted' })} className="text-[11px] text-[#5A8A6E] font-medium">Провести</button>}</td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </div>
    </Layout>
  )
}
