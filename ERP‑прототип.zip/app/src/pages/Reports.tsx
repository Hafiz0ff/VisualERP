import { Layout } from '@/components/layout/Layout'
import { useApp } from '@/store/AppContext'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

const productionByProduct = [
  { name: 'Штукат. белая', qty: 2850 }, { name: 'Штукат. серая', qty: 1920 },
  { name: 'Шпатлёвка', qty: 2100 }, { name: 'ЦПС М150', qty: 3600 },
  { name: 'ЦПС М200', qty: 2640 }, { name: 'Клад. раствор', qty: 1680 },
  { name: 'Плит. клей', qty: 1560 }, { name: 'Гидроиз.', qty: 960 },
  { name: 'Наливной пол', qty: 1320 }, { name: 'Клей газоб.', qty: 1440 },
]

const rawMaterialUsage = [
  { name: 'Цемент', value: 35, color: '#C0563F' }, { name: 'Песок', value: 25, color: '#2A5C8D' },
  { name: 'Гипс', value: 18, color: '#5A8A6E' }, { name: 'Добавки', value: 12, color: '#F0A830' },
  { name: 'Известь', value: 6, color: '#9E9E9E' }, { name: 'Пигменты', value: 4, color: '#D4CFC8' },
]

const monthlyProduction = [
  { month: 'Янв', qty: 9800 }, { month: 'Фев', qty: 11200 }, { month: 'Мар', qty: 14500 },
  { month: 'Апр', qty: 13800 }, { month: 'Май', qty: 16200 }, { month: 'Июн', qty: 18570 },
]

export default function Reports() {
  const { state } = useApp()
  const totalStockValue = state.finishedProducts.reduce((s, p) => s + p.stock * p.price, 0)
  const totalRawValue = state.rawMaterials.reduce((s, m) => s + m.warehouseStock * m.costPerUnit, 0)
  const avgBagPrice = state.finishedProducts.reduce((s, p) => s + p.price, 0) / state.finishedProducts.length

  return (
    <Layout title="Отчеты">
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-white border border-[#D4CFC8] p-4"><div className="text-[12px] text-[#5E5E5E] mb-1">Сырьё на складе</div><div className="text-[22px] font-bold">{totalRawValue.toLocaleString()} ₽</div></div>
        <div className="bg-white border border-[#D4CFC8] p-4"><div className="text-[12px] text-[#5E5E5E] mb-1">Готовая продукция</div><div className="text-[22px] font-bold">{totalStockValue.toLocaleString()} ₽</div></div>
        <div className="bg-white border border-[#D4CFC8] p-4"><div className="text-[12px] text-[#5E5E5E] mb-1">Выполнено заказов</div><div className="text-[22px] font-bold">{state.productionOrders.filter((o) => o.status === 'completed').length}</div></div>
        <div className="bg-white border border-[#D4CFC8] p-4"><div className="text-[12px] text-[#5E5E5E] mb-1">Средняя цена мешка</div><div className="text-[22px] font-bold">{Math.round(avgBagPrice)} ₽</div></div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-white border border-[#D4CFC8] p-5">
          <h3 className="text-[14px] font-semibold mb-4">Производство по месяцам</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={monthlyProduction} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#EFEBE6" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9E9E9E' }} axisLine={{ stroke: '#D4CFC8' }} />
              <YAxis tick={{ fontSize: 11, fill: '#9E9E9E' }} axisLine={{ stroke: '#D4CFC8' }} />
              <Tooltip contentStyle={{ background: '#fff', border: '1px solid #D4CFC8', borderRadius: '4px', fontSize: '12px' }} formatter={(v: number) => [`${v.toLocaleString()} меш.`, '']} />
              <Bar dataKey="qty" fill="#C0563F" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white border border-[#D4CFC8] p-5">
          <h3 className="text-[14px] font-semibold mb-4">Расход сырья по категориям (%)</h3>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={rawMaterialUsage} cx="50%" cy="50%" outerRadius={100} dataKey="value" label={({ name, value }) => `${name} ${value}%`} labelLine={false}>
                {rawMaterialUsage.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Pie>
              <Tooltip contentStyle={{ background: '#fff', border: '1px solid #D4CFC8', borderRadius: '4px', fontSize: '12px' }} formatter={(v: number) => [`${v}%`, '']} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white border border-[#D4CFC8] p-5 mb-6">
        <h3 className="text-[14px] font-semibold mb-4">Производство по продуктам</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={productionByProduct} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#EFEBE6" horizontal={false} />
            <XAxis type="number" tick={{ fontSize: 11, fill: '#9E9E9E' }} axisLine={{ stroke: '#D4CFC8' }} />
            <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: '#5E5E5E' }} axisLine={{ stroke: '#D4CFC8' }} width={80} />
            <Tooltip contentStyle={{ background: '#fff', border: '1px solid #D4CFC8', borderRadius: '4px', fontSize: '12px' }} formatter={(v: number) => [`${v.toLocaleString()} меш.`, '']} />
            <Bar dataKey="qty" fill="#2A5C8D" radius={[0, 2, 2, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-white border border-[#D4CFC8]">
        <div className="px-5 py-3 border-b border-[#D4CFC8]"><h3 className="text-[14px] font-semibold">Стоимостная оценка остатков</h3></div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="bg-[#EFEBE6]">
              <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Категория</th>
              <th className="px-4 py-3 text-[12px] font-semibold text-right border-b-2 border-[#2B2B2B]">Позиций</th>
              <th className="px-4 py-3 text-[12px] font-semibold text-right border-b-2 border-[#2B2B2B]">Остаток</th>
              <th className="px-4 py-3 text-[12px] font-semibold text-right border-b-2 border-[#2B2B2B]">Себестоимость ₽</th>
            </tr></thead>
            <tbody className="divide-y divide-[#F6F5F2]">
              {['Вяжущие', 'Заполнители', 'Добавки', 'Упаковка', 'Пигменты'].map((cat, idx) => {
                const mats = state.rawMaterials.filter((m) => m.category === cat)
                return (<tr key={cat} className={`h-10 ${idx % 2 === 1 ? 'bg-[#F6F5F2]' : 'bg-white'} hover:bg-[#EFEBE6]`}>
                  <td className="px-4 text-[13px] font-medium">{cat}</td>
                  <td className="px-4 text-[13px] text-right font-mono">{mats.length}</td>
                  <td className="px-4 text-[13px] text-right font-mono">{mats.reduce((s, m) => s + m.warehouseStock, 0).toLocaleString()}</td>
                  <td className="px-4 text-[13px] text-right font-mono">{mats.reduce((s, m) => s + m.warehouseStock * m.costPerUnit, 0).toLocaleString()} ₽</td>
                </tr>)
              })}
              <tr className="h-10 bg-[#EFEBE6] font-semibold"><td className="px-4">Итого сырьё</td><td className="px-4 text-right font-mono">{state.rawMaterials.length}</td><td className="px-4 text-right font-mono">—</td><td className="px-4 text-right font-mono">{totalRawValue.toLocaleString()} ₽</td></tr>
              <tr className="h-10 bg-[#EFEBE6] font-semibold"><td className="px-4">Итого продукция</td><td className="px-4 text-right font-mono">{state.finishedProducts.length}</td><td className="px-4 text-right font-mono">{state.finishedProducts.reduce((s, p) => s + p.stock, 0).toLocaleString()} меш.</td><td className="px-4 text-right font-mono">{totalStockValue.toLocaleString()} ₽</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  )
}
