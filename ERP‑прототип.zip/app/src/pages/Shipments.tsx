import { useState } from 'react'
import { Layout } from '@/components/layout/Layout'
import { useApp } from '@/store/AppContext'
import { Plus, X } from 'lucide-react'

interface ShItem { productId: string; productName: string; quantity: number; unit: string; price: number; total: number }

export default function Shipments() {
  const { state, dispatch } = useApp()
  const [showForm, setShowForm] = useState(false)
  const [customer, setCustomer] = useState('')
  const [responsible, setResponsible] = useState('')
  const [comment, setComment] = useState('')
  const [items, setItems] = useState<ShItem[]>([{ productId: '', productName: '', quantity: 0, unit: 'меш', price: 0, total: 0 }])

  const hChange = (i: number, f: keyof ShItem, v: unknown) => {
    const ni = [...items]
    if (f === 'productId') {
      const p = state.finishedProducts.find((x) => x.id === v)
      ni[i] = { ...ni[i], productId: v as string, productName: p?.name || '', price: p?.price || 0, total: ni[i].quantity * (p?.price || 0) }
    } else if (f === 'quantity') {
      const q = Number(v)
      ni[i] = { ...ni[i], quantity: q, total: q * ni[i].price }
    } else {
      ni[i] = { ...ni[i], [f]: v }
    }
    setItems(ni)
  }

  const hSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const valid = items.filter((it) => it.productId && it.quantity > 0)
    if (!valid.length) return
    dispatch({ type: 'ADD_SHIPMENT', payload: { date: '25.06.2024', customer, items: valid, totalSum: valid.reduce((s, it) => s + it.total, 0), responsible, comment } })
    setShowForm(false); setCustomer(''); setResponsible(''); setComment(''); setItems([{ productId: '', productName: '', quantity: 0, unit: 'меш', price: 0, total: 0 }])
  }

  return (
    <Layout title="Отгрузки">
      <div className="bg-white border border-[#D4CFC8] p-4 mb-4 flex items-center justify-between">
        <span className="text-[13px] text-[#5E5E5E]">Всего: <strong>{state.shipments.length}</strong> | Отгружено: <strong className="text-[#5A8A6E]">{state.shipments.filter((s) => s.status === 'shipped').length}</strong> | Черновики: <strong className="text-[#F0A830]">{state.shipments.filter((s) => s.status === 'draft').length}</strong></span>
        <button onClick={() => setShowForm(!showForm)} className="h-9 px-4 bg-[#C0563F] text-white text-[13px] font-medium rounded hover:bg-[#A84835] flex items-center gap-2"><Plus size={15} strokeWidth={2.5} /> Создать отгрузку</button>
      </div>

      {showForm && (
        <form onSubmit={hSubmit} className="bg-white border border-[#D4CFC8] p-5 mb-4">
          <div className="flex items-center justify-between mb-4"><h3 className="text-[14px] font-semibold">Новая отгрузка</h3><button type="button" onClick={() => setShowForm(false)} className="text-[#9E9E9E] hover:text-[#2B2B2B]"><X size={18} /></button></div>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div><label className="text-[12px] text-[#5E5E5E] block mb-1">Клиент</label><input type="text" value={customer} onChange={(e) => setCustomer(e.target.value)} placeholder="Название клиента" className="h-9 w-full px-3 text-[13px] bg-[#F6F5F2] border border-[#D4CFC8] rounded focus:outline-none focus:border-[#C0563F]" /></div>
            <div><label className="text-[12px] text-[#5E5E5E] block mb-1">Ответственный</label><input type="text" value={responsible} onChange={(e) => setResponsible(e.target.value)} className="h-9 w-full px-3 text-[13px] bg-[#F6F5F2] border border-[#D4CFC8] rounded focus:outline-none focus:border-[#C0563F]" /></div>
            <div><label className="text-[12px] text-[#5E5E5E] block mb-1">Комментарий</label><input type="text" value={comment} onChange={(e) => setComment(e.target.value)} className="h-9 w-full px-3 text-[13px] bg-[#F6F5F2] border border-[#D4CFC8] rounded" /></div>
          </div>
          <div className="border border-[#D4CFC8] rounded overflow-hidden mb-4">
            <table className="w-full"><thead className="bg-[#EFEBE6]"><tr><th className="px-3 py-2 text-[11px] font-semibold text-left">Продукт</th><th className="px-3 py-2 text-[11px] font-semibold text-center w-24">Кол-во</th><th className="px-3 py-2 text-[11px] font-semibold text-center w-16">Ед.</th><th className="px-3 py-2 text-[11px] font-semibold text-right w-24">Цена</th><th className="px-3 py-2 text-[11px] font-semibold text-right w-24">Сумма</th><th className="px-3 py-2 text-[11px] w-8"></th></tr></thead>
              <tbody className="divide-y divide-[#EFEBE6]">{items.map((it, idx) => (<tr key={idx} className="bg-white">
                <td className="px-3 py-2"><select value={it.productId} onChange={(e) => hChange(idx, 'productId', e.target.value)} className="h-8 w-full px-2 text-[12px] bg-[#F6F5F2] border border-[#D4CFC8] rounded"><option value="">Выберите...</option>{state.finishedProducts.map((p) => <option key={p.id} value={p.id}>{p.name} (ост. {p.stock} {p.unit})</option>)}</select></td>
                <td className="px-3 py-2"><input type="number" value={it.quantity || ''} onChange={(e) => hChange(idx, 'quantity', Number(e.target.value))} className="h-8 w-full px-2 text-[12px] bg-[#F6F5F2] border border-[#D4CFC8] rounded text-center" min="1" /></td>
                <td className="px-3 py-2 text-center text-[12px] text-[#5E5E5E]">{it.unit}</td>
                <td className="px-3 py-2 text-[12px] text-right font-mono">{it.price.toLocaleString()}</td>
                <td className="px-3 py-2 text-[12px] text-right font-mono">{it.total.toLocaleString()}</td>
                <td className="px-3 py-2 text-center">{items.length > 1 && <button type="button" onClick={() => setItems(items.filter((_, j) => j !== idx))} className="text-[#9E9E9E] hover:text-[#C0563F]"><X size={14} /></button>}</td>
              </tr>))}</tbody>
            </table>
          </div>
          <button type="button" onClick={() => setItems([...items, { productId: '', productName: '', quantity: 0, unit: 'меш', price: 0, total: 0 }])} className="mb-4 text-[12px] text-[#C0563F] font-medium flex items-center gap-1"><Plus size={12} /> Добавить</button>
          <div className="flex items-center justify-between">
            <div className="text-[12px] text-[#5E5E5E]">Итого: <strong className="text-[#2B2B2B]">{items.reduce((s, it) => s + it.total, 0).toLocaleString()} ₽</strong></div>
            <div className="flex gap-3"><button type="button" onClick={() => setShowForm(false)} className="h-9 px-4 text-[13px] font-medium text-[#5E5E5E] bg-white border border-[#D4CFC8] rounded hover:bg-[#F6F5F2]">Отмена</button><button type="submit" className="h-9 px-5 text-[13px] font-medium text-white bg-[#C0563F] rounded hover:bg-[#A84835]">Создать</button></div>
          </div>
        </form>
      )}

      <div className="bg-white border border-[#D4CFC8]">
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="bg-[#EFEBE6]">
            <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">№</th><th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Дата</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Клиент</th><th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Продукция</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-right border-b-2 border-[#2B2B2B]">Сумма</th><th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Ответственный</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-center border-b-2 border-[#2B2B2B]">Статус</th><th className="px-4 py-3 text-[12px] font-semibold text-center border-b-2 border-[#2B2B2B]"></th>
          </tr></thead>
            <tbody className="divide-y divide-[#F6F5F2]">{state.shipments.slice().reverse().map((sh, idx) => (
              <tr key={sh.id} className={`h-12 ${idx % 2 === 1 ? 'bg-[#F6F5F2]' : 'bg-white'} hover:bg-[#EFEBE6]`}>
                <td className="px-4 text-[12px] font-mono text-[#5E5E5E]">{sh.id}</td><td className="px-4 text-[12px]">{sh.date}</td>
                <td className="px-4 text-[12px] font-medium">{sh.customer}</td>
                <td className="px-4 text-[12px]">{sh.items.length} поз.<br/><span className="text-[10px] text-[#9E9E9E]">{sh.items.map((it) => `${it.productName} ×${it.quantity}`).join(', ')}</span></td>
                <td className="px-4 text-[12px] text-right font-mono">{sh.totalSum.toLocaleString()} ₽</td>
                <td className="px-4 text-[12px] text-[#5E5E5E]">{sh.responsible}</td>
                <td className="px-4 text-center"><span className={`inline-flex items-center px-2 py-0.5 text-[11px] font-medium rounded ${sh.status === 'shipped' ? 'bg-[#5A8A6E]/15 text-[#5A8A6E]' : sh.status === 'draft' ? 'bg-[#F0A830]/15 text-[#F0A830]' : 'bg-[#C0563F]/15 text-[#C0563F]'}`}>{sh.status === 'shipped' ? 'Отгружено' : sh.status === 'draft' ? 'Черновик' : 'Отменено'}</span></td>
                <td className="px-4 text-center">{sh.status === 'draft' && <button onClick={() => dispatch({ type: 'UPDATE_SHIPMENT_STATUS', id: sh.id, status: 'shipped' })} className="text-[11px] text-[#5A8A6E] font-medium">Отгрузить</button>}</td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </div>
    </Layout>
  )
}
