import { useState, useMemo } from 'react'
import { Layout } from '@/components/layout/Layout'
import { useApp } from '@/store/AppContext'
import { Plus, X } from 'lucide-react'

export default function Production() {
  const { state, dispatch } = useApp()
  const [showForm, setShowForm] = useState(false)
  const [detailId, setDetailId] = useState<string | null>(null)
  const [productId, setProductId] = useState('')
  const [recipeId, setRecipeId] = useState('')
  const [plannedQty, setPlannedQty] = useState('')
  const [responsible, setResponsible] = useState('')

  const recipe = useMemo(() => state.recipes.find((r) => r.id === recipeId), [recipeId, state.recipes])
  const calc = useMemo(() => {
    if (!recipe || !plannedQty) return []
    const q = Number(plannedQty); if (isNaN(q) || q <= 0) return []
    return recipe.ingredients.map((ing) => ({ ...ing, total: +(ing.quantityPerUnit * q).toFixed(2) }))
  }, [recipe, plannedQty])

  const hProduct = (pid: string) => {
    setProductId(pid)
    const r = state.recipes.find((rc) => rc.productId === pid)
    setRecipeId(r?.id || '')
  }

  const hSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const p = state.finishedProducts.find((pr) => pr.id === productId)
    if (!p) return
    dispatch({ type: 'ADD_PRODUCTION', payload: { date: '25.06.2024', productId, productName: p.name, recipeId, plannedQuantity: Number(plannedQty), actualQuantity: 0, responsible, plannedMaterials: calc.map((m) => ({ materialId: m.materialId, materialName: m.materialName, quantity: m.total, unit: m.unit })), actualMaterialsUsed: [] } })
    setShowForm(false); setProductId(''); setRecipeId(''); setPlannedQty(''); setResponsible('')
  }

  const sOrder = { planned: 0, in_progress: 1, completed: 2, cancelled: 3 }
  const detailOrder = detailId ? state.productionOrders.find((o) => o.id === detailId) : null

  return (
    <Layout title="Производство">
      <div className="bg-white border border-[#D4CFC8] p-4 mb-4 flex items-center justify-between">
        <span className="text-[13px] text-[#5E5E5E]">Всего: <strong>{state.productionOrders.length}</strong> | В работе: <strong className="text-[#2A5C8D]">{state.productionOrders.filter((o) => o.status === 'in_progress').length}</strong> | Выполнено: <strong className="text-[#5A8A6E]">{state.productionOrders.filter((o) => o.status === 'completed').length}</strong></span>
        <button onClick={() => setShowForm(!showForm)} className="h-9 px-4 bg-[#C0563F] text-white text-[13px] font-medium rounded hover:bg-[#A84835] flex items-center gap-2"><Plus size={15} strokeWidth={2.5} /> Новый заказ</button>
      </div>

      {showForm && (
        <form onSubmit={hSubmit} className="bg-white border border-[#D4CFC8] p-5 mb-4">
          <div className="flex items-center justify-between mb-4"><h3 className="text-[14px] font-semibold">Создание производственного заказа</h3><button type="button" onClick={() => setShowForm(false)} className="text-[#9E9E9E] hover:text-[#2B2B2B]"><X size={18} /></button></div>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div><label className="text-[12px] text-[#5E5E5E] block mb-1">Продукт</label><select value={productId} onChange={(e) => hProduct(e.target.value)} className="h-9 w-full px-3 text-[13px] bg-[#F6F5F2] border border-[#D4CFC8] rounded"><option value="">Выберите...</option>{state.finishedProducts.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
            <div><label className="text-[12px] text-[#5E5E5E] block mb-1">Плановое кол-во, меш.</label><input type="number" value={plannedQty} onChange={(e) => setPlannedQty(e.target.value)} className="h-9 w-full px-3 text-[13px] bg-[#F6F5F2] border border-[#D4CFC8] rounded" min="1" /></div>
            <div><label className="text-[12px] text-[#5E5E5E] block mb-1">Мастер</label><input type="text" value={responsible} onChange={(e) => setResponsible(e.target.value)} className="h-9 w-full px-3 text-[13px] bg-[#F6F5F2] border border-[#D4CFC8] rounded" /></div>
          </div>
          {calc.length > 0 && (
            <div className="mb-4 p-4 bg-[#F6F5F2] border border-[#D4CFC8] rounded">
              <h4 className="text-[12px] font-semibold mb-2">Расчёт потребности сырья ({plannedQty} меш.)</h4>
              <table className="w-full"><thead><tr className="border-b border-[#D4CFC8]"><th className="py-1.5 text-[11px] text-[#5E5E5E] text-left">Сырьё</th><th className="py-1.5 text-[11px] text-[#5E5E5E] text-right">На 1 меш.</th><th className="py-1.5 text-[11px] text-[#5E5E5E] text-right">План</th></tr></thead>
                <tbody>{calc.map((m) => <tr key={m.materialId} className="border-b border-[#EFEBE6]"><td className="py-1.5 text-[12px]">{m.materialName}</td><td className="py-1.5 text-[12px] text-[#5E5E5E] text-right font-mono">{m.quantityPerUnit} {m.unit}</td><td className="py-1.5 text-[12px] text-[#C0563F] text-right font-mono font-medium">{m.total} {m.unit}</td></tr>)}</tbody>
              </table>
            </div>
          )}
          <div className="flex justify-end gap-3"><button type="button" onClick={() => setShowForm(false)} className="h-9 px-4 text-[13px] font-medium text-[#5E5E5E] bg-white border border-[#D4CFC8] rounded hover:bg-[#F6F5F2]">Отмена</button><button type="submit" disabled={!productId || !plannedQty || !responsible} className="h-9 px-5 text-[13px] font-medium text-white bg-[#C0563F] rounded hover:bg-[#A84835] disabled:opacity-50">Создать</button></div>
        </form>
      )}

      {/* Detail card */}
      {detailOrder && (
        <div className="bg-white border border-[#D4CFC8] p-5 mb-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <span className="text-[14px] font-mono font-semibold text-[#2B2B2B]">{detailOrder.id}</span>
              <span className="text-[18px] font-semibold text-[#2B2B2B]">{detailOrder.productName}</span>
              <span className={`inline-flex items-center px-2 py-0.5 text-[11px] font-medium rounded ${detailOrder.status === 'completed' ? 'bg-[#5A8A6E]/15 text-[#5A8A6E]' : detailOrder.status === 'in_progress' ? 'bg-[#2A5C8D]/15 text-[#2A5C8D]' : detailOrder.status === 'planned' ? 'bg-[#9E9E9E]/15 text-[#9E9E9E]' : 'bg-[#C0563F]/15 text-[#C0563F]'}`}>
                {detailOrder.status === 'completed' ? 'Выполнено' : detailOrder.status === 'in_progress' ? 'В работе' : detailOrder.status === 'planned' ? 'План' : 'Отменён'}
              </span>
            </div>
            <button onClick={() => setDetailId(null)} className="text-[#9E9E9E] hover:text-[#2B2B2B]"><X size={18} /></button>
          </div>
          <div className="grid grid-cols-4 gap-4 mb-4 text-[12px]">
            <div><span className="text-[#9E9E9E]">План:</span> <span className="font-medium">{detailOrder.plannedQuantity} меш.</span></div>
            <div><span className="text-[#9E9E9E]">Факт:</span> <span className="font-medium">{detailOrder.actualQuantity || '—'} меш.</span></div>
            <div><span className="text-[#9E9E9E]">Мастер:</span> <span className="font-medium">{detailOrder.responsible}</span></div>
            <div><span className="text-[#9E9E9E]">Дата:</span> <span className="font-medium">{detailOrder.date}</span></div>
            <div><span className="text-[#9E9E9E]">Запуск:</span> <span className="font-medium">{detailOrder.startDate || '—'}</span></div>
            <div><span className="text-[#9E9E9E]">Завершение:</span> <span className="font-medium">{detailOrder.endDate || '—'}</span></div>
            <div><span className="text-[#9E9E9E]">Рецептура:</span> <span className="font-medium font-mono">{detailOrder.recipeId}</span></div>
          </div>
          {detailOrder.plannedMaterials.length > 0 && (
            <div className="mb-4"><h4 className="text-[12px] font-semibold mb-2">Плановое списание сырья</h4>
              <table className="w-full border border-[#D4CFC8]"><thead className="bg-[#EFEBE6]"><tr><th className="px-3 py-2 text-[11px] font-semibold text-left">Сырьё</th><th className="px-3 py-2 text-[11px] font-semibold text-center">Партия</th><th className="px-3 py-2 text-[11px] font-semibold text-right">Кол-во</th><th className="px-3 py-2 text-[11px] font-semibold text-center">Ед.</th></tr></thead>
                <tbody className="divide-y divide-[#EFEBE6]">{detailOrder.plannedMaterials.map((m, i) => (<tr key={i} className="bg-white"><td className="px-3 py-2 text-[12px]">{m.materialName}</td><td className="px-3 py-2 text-[11px] font-mono text-center text-[#5E5E5E]">{m.batchId || '—'}</td><td className="px-3 py-2 text-[12px] text-right font-mono">{m.quantity}</td><td className="px-3 py-2 text-[11px] text-center">{m.unit}</td></tr>))}</tbody>
              </table></div>
          )}
          {detailOrder.actualMaterialsUsed.length > 0 && (
            <div className="mb-4"><h4 className="text-[12px] font-semibold mb-2">Фактическое списание сырья</h4>
              <table className="w-full border border-[#D4CFC8]"><thead className="bg-[#EFEBE6]"><tr><th className="px-3 py-2 text-[11px] font-semibold text-left">Сырьё</th><th className="px-3 py-2 text-[11px] font-semibold text-center">Партия</th><th className="px-3 py-2 text-[11px] font-semibold text-right">Кол-во</th><th className="px-3 py-2 text-[11px] font-semibold text-center">Ед.</th></tr></thead>
                <tbody className="divide-y divide-[#EFEBE6]">{detailOrder.actualMaterialsUsed.map((m, i) => (<tr key={i} className="bg-white"><td className="px-3 py-2 text-[12px]">{m.materialName}</td><td className="px-3 py-2 text-[11px] font-mono text-center text-[#5E5E5E]">{m.batchId || '—'}</td><td className="px-3 py-2 text-[12px] text-right font-mono">{m.quantity}</td><td className="px-3 py-2 text-[11px] text-center">{m.unit}</td></tr>))}</tbody>
              </table></div>
          )}
          <div className="flex gap-2">
            {detailOrder.status === 'planned' && <button onClick={() => { dispatch({ type: 'UPDATE_PRODUCTION_STATUS', id: detailOrder.id, status: 'in_progress' }); setDetailId(null); }} className="h-8 px-4 text-[12px] font-medium text-white bg-[#2A5C8D] rounded hover:bg-[#1A4C7D]">В работу</button>}
            {detailOrder.status === 'in_progress' && <button onClick={() => { dispatch({ type: 'UPDATE_PRODUCTION_STATUS', id: detailOrder.id, status: 'completed' }); setDetailId(null); }} className="h-8 px-4 text-[12px] font-medium text-white bg-[#5A8A6E] rounded hover:bg-[#4A7A5E]">Завершить</button>}
            {(detailOrder.status === 'planned' || detailOrder.status === 'in_progress') && <button onClick={() => { dispatch({ type: 'UPDATE_PRODUCTION_STATUS', id: detailOrder.id, status: 'cancelled' }); setDetailId(null); }} className="h-8 px-4 text-[12px] font-medium text-white bg-[#C0563F] rounded hover:bg-[#A84835]">Отменить</button>}
          </div>
        </div>
      )}

      <div className="bg-white border border-[#D4CFC8]">
        <div className="overflow-x-auto">
          <table className="w-full"><thead><tr className="bg-[#EFEBE6]">
            <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">№</th><th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Дата</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Продукт</th><th className="px-4 py-3 text-[12px] font-semibold text-right border-b-2 border-[#2B2B2B]">План</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-right border-b-2 border-[#2B2B2B]">Факт</th><th className="px-4 py-3 text-[12px] font-semibold text-left border-b-2 border-[#2B2B2B]">Мастер</th>
            <th className="px-4 py-3 text-[12px] font-semibold text-center border-b-2 border-[#2B2B2B]">Статус</th><th className="px-4 py-3 text-[12px] font-semibold text-center border-b-2 border-[#2B2B2B]"></th>
          </tr></thead>
            <tbody className="divide-y divide-[#F6F5F2]">{state.productionOrders.slice().sort((a, b) => sOrder[a.status] - sOrder[b.status] || b.id.localeCompare(a.id)).map((o) => (
              <tr key={o.id} className={`h-12 hover:bg-[#EFEBE6] cursor-pointer ${detailId === o.id ? 'bg-[#F6F5F2]' : ''}`} onClick={() => setDetailId(detailId === o.id ? null : o.id)}>
                <td className="px-4 text-[12px] font-mono text-[#5E5E5E]">{o.id}</td><td className="px-4 text-[12px]">{o.date}</td>
                <td className="px-4 text-[13px] font-medium">{o.productName}{o.startDate && <span className="block text-[10px] text-[#9E9E9E]">{o.startDate}{o.endDate ? ` — ${o.endDate}` : ''}</span>}</td>
                <td className="px-4 text-[13px] text-right font-mono">{o.plannedQuantity}</td>
                <td className="px-4 text-[13px] text-right font-mono">{o.actualQuantity || '—'}</td>
                <td className="px-4 text-[12px] text-[#5E5E5E]">{o.responsible}</td>
                <td className="px-4 text-center"><span className={`inline-flex items-center px-2 py-0.5 text-[11px] font-medium rounded ${o.status === 'completed' ? 'bg-[#5A8A6E]/15 text-[#5A8A6E]' : o.status === 'in_progress' ? 'bg-[#2A5C8D]/15 text-[#2A5C8D]' : o.status === 'planned' ? 'bg-[#9E9E9E]/15 text-[#9E9E9E]' : 'bg-[#C0563F]/15 text-[#C0563F]'}`}>{o.status === 'completed' ? 'Выполнено' : o.status === 'in_progress' ? 'В работе' : o.status === 'planned' ? 'План' : 'Отменён'}</span></td>
                <td className="px-4 text-center"><div className="flex items-center justify-center gap-2">
                  {o.status === 'planned' && <button onClick={(e) => { e.stopPropagation(); dispatch({ type: 'UPDATE_PRODUCTION_STATUS', id: o.id, status: 'in_progress' }); }} className="text-[11px] text-[#2A5C8D] font-medium">В работу</button>}
                  {o.status === 'in_progress' && <button onClick={(e) => { e.stopPropagation(); dispatch({ type: 'UPDATE_PRODUCTION_STATUS', id: o.id, status: 'completed' }); }} className="text-[11px] text-[#5A8A6E] font-medium">Завершить</button>}
                </div></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </div>
    </Layout>
  )
}
