import type { ReactNode } from 'react'
import { Search, Bell } from 'lucide-react'

interface LayoutProps {
  children: ReactNode
  title: string
}

export function Layout({ children, title }: LayoutProps) {
  return (
    <>
      {/* Topbar */}
      <header className="sticky top-0 h-14 bg-white border-b border-[#D4CFC8] flex items-center justify-between px-6 z-40">
        <h1 className="text-[18px] font-semibold text-[#2B2B2B]">{title}</h1>
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9E9E9E]" />
            <input
              type="text"
              placeholder="Поиск..."
              className="h-8 w-56 pl-9 pr-3 text-[13px] bg-[#F6F5F2] border border-[#D4CFC8] rounded focus:outline-none focus:border-[#C0563F] focus:ring-2 focus:ring-[#C0563F]/20"
            />
          </div>
          <button className="relative p-2 text-[#5E5E5E] hover:text-[#2B2B2B] transition-colors">
            <Bell size={18} strokeWidth={2} />
            <span className="absolute top-1 right-1 w-2 h-2 bg-[#C0563F] rounded-full" />
          </button>
        </div>
      </header>

      {/* Page Content */}
      <div className="p-6">
        {children}
      </div>
    </>
  )
}
