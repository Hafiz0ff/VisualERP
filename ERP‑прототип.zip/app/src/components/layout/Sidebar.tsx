import { NavLink } from 'react-router'
import {
  LayoutDashboard,
  Warehouse,
  Factory,
  ArrowRightLeft,
  FlaskConical,
  PackageCheck,
  BarChart3,
} from 'lucide-react'
import { cn } from '@/lib/utils'

const navItems = [
  { to: '/', label: 'Главная', icon: LayoutDashboard },
  { to: '/raw-materials', label: 'Склад сырья', icon: Warehouse },
  { to: '/workshop', label: 'Цех', icon: Factory },
  { to: '/transfers', label: 'Передачи', icon: ArrowRightLeft },
  { to: '/production', label: 'Производство', icon: FlaskConical },
  { to: '/recipes', label: 'Рецептуры', icon: PackageCheck },
  { to: '/products', label: 'Готовая продукция', icon: PackageCheck },
  { to: '/reports', label: 'Отчеты', icon: BarChart3 },
]

export function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 h-full w-[240px] bg-white border-r border-[#D4CFC8] flex flex-col z-50">
      <div className="h-14 flex items-center px-4 border-b border-[#D4CFC8]">
        <span className="text-[15px] font-bold tracking-wide text-[#2B2B2B] uppercase">
          ПромСтройСмеси
        </span>
      </div>

      <nav className="flex-1 py-3 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            className={({ isActive }) =>
              cn(
                'flex items-center gap-3 h-10 px-4 mx-2 text-[13px] font-medium transition-colors',
                'text-[#5E5E5E] hover:bg-[#F6F5F2] hover:text-[#2B2B2B]',
                isActive && 'bg-[#F6F5F2] text-[#C0563F] border-l-[3px] border-l-[#C0563F]'
              )
            }
          >
            <item.icon size={18} strokeWidth={2} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-[#D4CFC8]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-[#C0563F] flex items-center justify-center text-white text-[13px] font-bold">
            А
          </div>
          <div className="flex flex-col">
            <span className="text-[12px] font-medium text-[#2B2B2B]">Администратор</span>
            <span className="text-[11px] text-[#9E9E9E]">admin@promstroy.ru</span>
          </div>
        </div>
      </div>
    </aside>
  )
}
